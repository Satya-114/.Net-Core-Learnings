﻿namespace RepositoryPattern.Models
{
    public class Book
    {
        public int  BookId { get; set; }
        public string BookTitle { get; set; }
        public string Standard { get; set; }
        public string Subject { get; set; }
        public string Author { get; set; }

        
    }
}
